ANTHONY'S GRAPHICS — WEBSITE FILES

CONTENTS
- index.html: website content and sections
- style.css: layout, colours, typography and responsive styling
- script.js: mobile navigation, portfolio filters and current year

HOW TO PREVIEW
1. Extract this ZIP file.
2. Open the extracted folder.
3. Double-click index.html to preview it in a browser.
   An internet connection is needed for the Google Fonts.

BEFORE PUBLISHING
1. Open index.html in a text editor.
2. Find "ADD YOUR PHONE NUMBER" and replace it with your real phone number.
3. Replace +2340000000000 in the tel: and WhatsApp links with your number in international format, digits only for the WhatsApp URL (example: 2348012345678).
4. Replace hello@anthonysgraphics.com with your real email address.
5. Replace the sample portfolio concepts with your own project images and descriptions.
6. Update the About section if you want different biography text.

PUBLISH ON NETLIFY
1. Extract this ZIP.
2. Go to https://app.netlify.com/drop
3. Drag the extracted website folder (the folder containing index.html) onto the page.
4. Netlify will publish the static website and provide a netlify.app address.
5. To connect a custom domain, open your site's Domain management in Netlify and follow the DNS instructions.

NOTE
This is a static landing page. Forms, payments, client logins, private downloads and database-powered dashboards are not connected in this version. Those require additional services/backend integration.
